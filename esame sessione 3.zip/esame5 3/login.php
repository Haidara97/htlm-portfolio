<?php
// Start session
session_start();


?>
<!DOCTYPE html>
<html>
<head>
    <title>Log In</title>
    <link rel="stylesheet" href="signup.css">
    
    <style>
        .success-message {
            color: green;
            font-weight: bold;
            text-align: center;
            position: fixed;
            top: 0;
            left: 50%;
            width: fit-content;
            transform: translateX(-50%);
            padding: 10px;
            background-color: #dff0d8; /* Green background for Bootstrap-like styling */
            border: 1px solid #3c763d; /* Green border for Bootstrap-like styling */
            border-radius: 4px; /* Optional: Round the corners for Bootstrap-like styling */
            
        }
    </style>
</head>
<body>

<div class="success-message" id="successMessage">
    <?php
    // Check if there is a success message in the session
    if (isset($_SESSION['signup_success'])) {
        // Display the success message
        echo $_SESSION['signup_success'];
        
        // Unset the session variable
        unset($_SESSION['signup_success']);
    }
    ?>
</div>

<div class="container">
    <h1>Log In</h1>
    <form action="login_process.php" method="post">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="question">Don't have an account? <span><a href="signup.php">Sign Up</a></span></div>
        <button type="submit">Log In</button>
    </form>
</div>

<?php include 'alert.php'; ?>

<script>
    // Display the success message and make it vanish after 2 seconds
    document.addEventListener("DOMContentLoaded", function () {
        var successMessage = document.getElementById("successMessage");
        if (successMessage) {
            successMessage.style.display = "block";
            setTimeout(function () {
                successMessage.style.display = "none";
            }, 2000); // 2000 milliseconds = 2 seconds
        }
    });
</script>
</body>
</html>
