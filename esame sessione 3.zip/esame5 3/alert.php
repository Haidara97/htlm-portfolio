<?php
// Display success or error messages using SweetAlert
if (isset($_SESSION['success'])):
    echo "<script>
            swal('Success', '{$_SESSION['success']}', 'success');
         </script>";
    unset($_SESSION['success']);
endif;

if (isset($_SESSION['error'])):
    echo "<script>
            swal('Error', '{$_SESSION['error']}', 'error');
         </script>";
    unset($_SESSION['error']);
endif;
?>
