<?php
// Start session
session_start();


?>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <link rel="stylesheet" href="signup.css">
    <style>
        .error-message {
            color: green;
            font-weight: bold;
            text-align: center;
            position: fixed;
            top: 0;
            left: 50%;
            width: fit-content;
            transform: translateX(-50%);
            padding: 10px;
            background-color: #dff0d8; /* Green background for Bootstrap-like styling */
            border: 1px solid #3c763d; /* Green border for Bootstrap-like styling */
            border-radius: 4px; /* Optional: Round the corners for Bootstrap-like styling */
            
        }
    </style>
    
</head>
<body>
<div class="success-message" id="successMessage">
    <?php
   // Check if there is an error message in the session
if (isset($_SESSION['signup_error'])) {
    // Display the error message
    echo "<div class='error-message' id='errorMessage'>".$_SESSION['signup_error']."</div>";
    
    // Unset the session variable
    unset($_SESSION['signup_error']);
}
    ?>
</div>
    <div class="container">
        <h1>Sign Up</h1>
        <form action="signup_process.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="question">Already have an account? <span><a href="login.php">Login</a></span></div> 
            <button type="submit">Sign Up</button>
        </form>
    </div>

    <script>
    // Display the success message and make it vanish after 2 seconds
    document.addEventListener("DOMContentLoaded", function () {
        var errorMessage = document.getElementById("errorMessage");
        if (errorMessage) {
            errorMessage.style.display = "block";
            setTimeout(function () {
                errorMessage.style.display = "none";
            }, 2000); // 2000 milliseconds = 2 seconds
        }
    });
</script>


</body>
</html>
