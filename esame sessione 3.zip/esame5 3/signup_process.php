<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact_db";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password for security

    // Check email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        session_start();
        $_SESSION['signup_error'] = "Invalid email format";
        header("Location: signup.php");
        exit();
    }

    // Check if email is unique
    $checkEmailQuery = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($checkEmailQuery);

    if ($result->num_rows > 0) {
        session_start();
        $_SESSION['signup_error'] = "Email already exists. Choose a different email.";
        header("Location: signup.php");
        exit();
    }

    // Insert data into the database
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Set success message in session variable
        session_start();
        $_SESSION['signup_success'] = "Registration successful";
        
        // Close the database connection
        $conn->close();
        
        // Redirect immediately
        header("Location: login.php");
        exit();
    } else {
        // Set error message in session variable
        session_start();
        $_SESSION['signup_error'] = "Error: " . $sql . "<br>" . $conn->error;

        // Redirect to the same page
        header("Location: signup.php");
        exit();
    }
}

// Close the database connection
$conn->close();
?>
