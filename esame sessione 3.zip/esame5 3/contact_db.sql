-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2024 at 05:22 AM
-- Server version: 8.0.31
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Contact_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `password`) VALUES
('qAyKVlR6qwJqv2gYePvz', 'admin', '$2y$10$gnvFoU2mPZmVZ0ZFV7LJbu.Alv4b.hZhQzVoT37Md5dYnhiWP2vKe');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_name` text COLLATE utf8mb4_general_ci NOT NULL,
  `category_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `id` int NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_name`, `category_description`, `id`, `icon`) VALUES
('full Website Development', 'Hi, I\'m Suleimana Haidara, Your Go-To Partner For All Things Web Development. With A Passion For Turning Ideas Into Interactive And Visually Stunning Websites, I Specialize In Crafting Digital Experiences That Leave A Lasting Impression.', 1, 'flaticon-analysis'),
('Web Design', 'Greetings! I\'m Suleimana Haidara, Your Dedicated Partner In Bringing Visual Brilliance To The Digital World. As A Seasoned Web Designer, I Specialize In Creating Aesthetically Pleasing And User-Centric Designs That Leave A Lasting Impression.', 2, 'flaticon-flasks'),
('API Integration', 'Meet Bootstrap, The Game-Changer In Web Development That Simplifies The Art Of Creating Responsive And Visually Appealing Websites. I\'m Suleimana, Your Guide To Harnessing The Power Of Bootstrap For A Seamless And Efficient Web Design Experience.', 3, 'flaticon-ideas'),
('Back End Solutions', 'Hello, I\'m Suleimana Haidara, Your Expert Partner In Crafting Robust Backend Solutions That Form The Backbone Of Your Digital Endeavors. With A Focus On Functionality, Security, And Scalability, I Specialize In Building The Engines That Power Your Online Presence.', 4, 'flaticon-analysis'),
('Database Management', 'Hello, I\'m Suleimana, Your Dedicated Partner In The Realm Of Database Management. With A Passion For Organizing, Optimizing, And Securing Data, I Specialize In Creating Robust And Efficient Database Solutions Tailored To Meet Your Business Needs.', 5, 'flaticon-flasks'),
('Wordpress', '', 6, 'flaticon-ideas');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `number` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `number`, `email`, `message`, `created_at`) VALUES
(9, 'test', '12345677', 'suleimane@gmail.com', 'message demo', '2023-12-31 12:25:19');

-- --------------------------------------------------------

--
-- Table structure for table `mywork`
--

CREATE TABLE `mywork` (
  `id` int NOT NULL,
  `work_name` text COLLATE utf8mb4_general_ci NOT NULL,
  `work_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mywork`
--

INSERT INTO `mywork` (`id`, `work_name`, `work_description`, `image_url`) VALUES
(1, 'Whats App', 'I Created An App That Allows Users To Message Each Other.', 'images/img-1.jpg'),
(2, 'Web Scrapper', 'this text is for demo', 'images/img-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(30, 'SULEIMANA HAIDARA', 'suleimane@gmail.com', '$2y$10$ZEujpOVkiFb/XmbZN3YbZ.bQX7QMNhHt0sPGg6UvVauRS8JNsb5XO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mywork`
--
ALTER TABLE `mywork`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mywork`
--
ALTER TABLE `mywork`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
